# Privacy Policy for "Erie Recorder for Chrome" (or this extension)

1. The following Chrome Extension API permissions are used in this extension:

- tabs: to query a tab
- tabCapture: to record sound generated from your current tab
- downloads: to enable auotmatic download for generated sounds and files (this is used because this recorder uses "Blob" which might be gone after a while).

2. This extension does not collect/send/store whatever your personal information. Everything works locally.
